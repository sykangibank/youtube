const Nav = () => {
  return(
    <>
      <ul>
        <li>
          <p>Youtube</p>
        </li>
        <li><button>search</button></li>
      </ul>
    </>
  )
}

export default Nav;